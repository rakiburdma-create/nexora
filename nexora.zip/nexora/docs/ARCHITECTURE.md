# NEXORA Architecture

## Layers (feature-first, clean layering)
- `core/` theme, router, l10n, notifications, utils, shared widgets
- `data/` Drift database, DAOs, repositories (single source of truth = SQLite)
- `domain/` pure Dart: entities, scheduling + recovery algorithms (unit-testable, no Flutter imports)
- `features/<module>/` presentation (screens/widgets) + Riverpod providers
UI -> Riverpod providers -> repositories -> Drift DAOs. Algorithms live in `domain/` and take plain inputs.

## Key decisions
1. **Offline-first**: all reads/writes hit Drift. Cloud backup (Supabase/Firebase) is an optional, one-way-then-merge sync of an exported snapshot; never required.
2. **Prayer times**: `adhan_dart` (local calculation, no network). Location via geolocator or manual city entry; method + madhab + per-prayer offsets stored in `app_settings`.
3. **Alarms**: `flutter_local_notifications` with `zonedSchedule` + `exactAllowWhileIdle`. Requires POST_NOTIFICATIONS (Android 13+), SCHEDULE_EXACT_ALARM / USE_EXACT_ALARM, RECEIVE_BOOT_COMPLETED. A `RescheduleService` re-plans the next 7 days of alarms on: boot, timezone change, app launch, settings change, midnight. Battery-optimization exemption is requested with an explanatory screen.
4. **AI**: Flutter -> your backend (`backend/`, Cloud Run / Cloudflare Worker) -> Claude API. APK holds only a backend URL + per-install token. Backend holds the API key, rate-limits, and builds the system prompt per class from syllabus context sent by the app.
5. **AI honesty rules** (enforced in the backend system prompt): answer in Bengali, prioritise the class syllabus, never fabricate textbook quotes/page numbers, label general knowledge as "general explanation, not from your textbook".
6. **Syllabus scheduler** (`domain/scheduler`): inputs = lessons (ordered), teaching days from class_schedules, holidays, exam dates, per-day capacity, semester window. Output = `daily_study_plans`. Lessons are only completed by explicit user action (`progress_logs`).
7. **Recovery**: remaining lessons / remaining available days -> required rate vs original rate -> redistribute respecting per-day capacity; if infeasible, return 3 alternatives (extend deadline, raise capacity, drop/merge low-priority lessons).
8. **i18n**: ARB files bn/en. Fonts: Hind Siliguri (Bengali), Inter (Latin), Amiri-style display optional for Arabic.
9. **Testing**: unit (scheduler, recovery, conflict detection), Drift in-memory DB tests, widget tests for dashboard, integration test for alarm rescheduling logic.

## Module build order
Foundation -> Dashboard -> Tasks/Reminders/Calendar -> Prayer -> Classes -> Syllabus + Recovery -> Notes -> AI -> Analytics -> Settings/Backup.
