# NEXORA
Life. Learn. Teach. Grow.

## APK বানানোর নিয়ম (কিছু ইনস্টল করতে হবে না)
1. github.com-এ বিনামূল্যে অ্যাকাউন্ট খুলুন, নতুন একটি repository বানান।
2. এই nexora ফোল্ডারের সব ফাইল (.github ফোল্ডারসহ) সেখানে আপলোড করুন।
3. repository-র "Actions" ট্যাবে যান, "Build NEXORA APK" চলতে দিন (৫-১০ মিনিট)।
4. শেষ হলে রানের পাতার নিচে "Artifacts" থেকে nexora-apk ডাউনলোড করুন, ভেতরের app-release.apk ফোনে ইনস্টল করুন।
ব্যর্থ হলে লগের লাল অংশ কপি করে পাঠান।
