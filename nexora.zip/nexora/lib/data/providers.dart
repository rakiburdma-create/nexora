import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'db/app_database.dart';

final databaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  ref.onDispose(db.close);
  return db;
});

final tasksProvider = StreamProvider<List<Task>>((ref) {
  final db = ref.watch(databaseProvider);
  return (db.select(db.tasks)
        ..orderBy([
          (t) => OrderingTerm.asc(t.isDone),
          (t) => OrderingTerm.asc(t.createdAt),
        ]))
      .watch();
});

final classesProvider = StreamProvider<List<SchoolClass>>((ref) {
  final db = ref.watch(databaseProvider);
  return db.select(db.classes).watch();
});

final subjectsProvider = StreamProvider<List<Subject>>((ref) {
  final db = ref.watch(databaseProvider);
  return db.select(db.subjects).watch();
});

final schedulesProvider = StreamProvider<List<ClassSchedule>>((ref) {
  final db = ref.watch(databaseProvider);
  return (db.select(db.classSchedules)
        ..orderBy([
          (s) => OrderingTerm.asc(s.weekday),
          (s) => OrderingTerm.asc(s.startMinute),
        ]))
      .watch();
});

final notesProvider = StreamProvider<List<Note>>((ref) {
  final db = ref.watch(databaseProvider);
  return (db.select(db.notes)..orderBy([(n) => OrderingTerm.desc(n.updatedAt)]))
      .watch();
});

class LessonRow {
  const LessonRow(this.item, this.subject);
  final SyllabusItem item;
  final Subject subject;
}

final lessonsProvider =
    StreamProvider.family<List<LessonRow>, int>((ref, classId) {
  final db = ref.watch(databaseProvider);
  final q = db.select(db.syllabusItems).join([
    innerJoin(db.subjects, db.subjects.id.equalsExp(db.syllabusItems.subjectId)),
  ])
    ..where(db.subjects.classId.equals(classId))
    ..orderBy([
      OrderingTerm.asc(db.subjects.id),
      OrderingTerm.asc(db.syllabusItems.orderIndex),
    ]);
  return q.watch().map((rows) => rows
      .map((r) => LessonRow(r.readTable(db.syllabusItems), r.readTable(db.subjects)))
      .toList());
});

final semestersProvider =
    StreamProvider.family<List<Semester>, int>((ref, classId) {
  final db = ref.watch(databaseProvider);
  return (db.select(db.semesters)
        ..where((s) => s.classId.equals(classId))
        ..orderBy([(s) => OrderingTerm.desc(s.startDate)]))
      .watch();
});

final plansProvider =
    StreamProvider.family<List<DailyStudyPlan>, int>((ref, semesterId) {
  final db = ref.watch(databaseProvider);
  return (db.select(db.dailyStudyPlans)
        ..where((p) => p.semesterId.equals(semesterId)))
      .watch();
});
