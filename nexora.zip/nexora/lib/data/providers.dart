import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'db/app_database.dart';

final databaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  ref.onDispose(db.close);
  return db;
});

final tasksProvider = StreamProvider<List<Task>>((ref) {
  final db = ref.watch(databaseProvider);
  return (db.select(db.tasks)
        ..orderBy([
          (t) => OrderingTerm.asc(t.isDone),
          (t) => OrderingTerm.asc(t.createdAt),
        ]))
      .watch();
});

final classesProvider = StreamProvider<List<SchoolClass>>((ref) {
  final db = ref.watch(databaseProvider);
  return db.select(db.classes).watch();
});

final subjectsProvider = StreamProvider<List<Subject>>((ref) {
  final db = ref.watch(databaseProvider);
  return db.select(db.subjects).watch();
});

final schedulesProvider = StreamProvider<List<ClassSchedule>>((ref) {
  final db = ref.watch(databaseProvider);
  return (db.select(db.classSchedules)
        ..orderBy([
          (s) => OrderingTerm.asc(s.weekday),
          (s) => OrderingTerm.asc(s.startMinute),
        ]))
      .watch();
});
