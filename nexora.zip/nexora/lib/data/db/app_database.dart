import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';
import 'tables.dart';

part 'app_database.g.dart';

@DriftDatabase(tables: [
  Users, Folders, Notes, Tags, NoteTags, Tasks, Attachments, Prayers,
  PrayerLogs, Classes, Subjects, ClassSchedules, Semesters, SyllabusItems,
  DailyStudyPlans, ProgressLogs, AiConversations, AiMessages, Reminders,
  AppSettings,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase([QueryExecutor? executor])
      : super(executor ?? driftDatabase(name: 'nexora'));

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        beforeOpen: (details) async {
          await customStatement('PRAGMA foreign_keys = ON');
        },
        onCreate: (m) async {
          await m.createAll();
          for (final k in ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha']) {
            await into(prayers).insert(PrayersCompanion.insert(key: k));
          }
        },
        // Add one `from < N` block per future schemaVersion bump.
        onUpgrade: (m, from, to) async {},
      );
}
