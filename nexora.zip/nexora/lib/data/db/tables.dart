import 'package:drift/drift.dart';

// Conventions: integer autoincrement PKs, createdAt/updatedAt epoch via DateTime,
// soft-delete via deletedAt where "trash" is required. Dates stored as DateTime.

class Users extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get displayName => text().withLength(min: 1, max: 80)();
  TextColumn get language => text().withDefault(const Constant('bn'))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

class Folders extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().withLength(min: 1, max: 100)();
  IntColumn get parentId => integer().nullable().references(Folders, #id)();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

class Notes extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get folderId => integer().nullable().references(Folders, #id)();
  TextColumn get title => text().withDefault(const Constant(''))();
  TextColumn get contentJson => text().withDefault(const Constant('[]'))(); // Quill delta
  TextColumn get plainText => text().withDefault(const Constant(''))(); // for search
  BoolColumn get isFavorite => boolean().withDefault(const Constant(false))();
  BoolColumn get isArchived => boolean().withDefault(const Constant(false))();
  DateTimeColumn get deletedAt => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
}

class Tags extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().unique()();
  IntColumn get colorValue => integer().nullable()();
}

class NoteTags extends Table {
  IntColumn get noteId => integer().references(Notes, #id, onDelete: KeyAction.cascade)();
  IntColumn get tagId => integer().references(Tags, #id, onDelete: KeyAction.cascade)();
  @override
  Set<Column> get primaryKey => {noteId, tagId};
}

class Tasks extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get title => text().withLength(min: 1, max: 200)();
  TextColumn get details => text().nullable()();
  IntColumn get sourceNoteId => integer().nullable().references(Notes, #id)();
  DateTimeColumn get dueAt => dateTime().nullable()();
  IntColumn get priority => integer().withDefault(const Constant(1))(); // 0 low..2 high
  BoolColumn get isDone => boolean().withDefault(const Constant(false))();
  DateTimeColumn get completedAt => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

class Attachments extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get noteId => integer().nullable().references(Notes, #id, onDelete: KeyAction.cascade)();
  IntColumn get taskId => integer().nullable().references(Tasks, #id, onDelete: KeyAction.cascade)();
  TextColumn get filePath => text()();
  TextColumn get mimeType => text().nullable()();
  IntColumn get sizeBytes => integer().withDefault(const Constant(0))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

// Prayers: static definition rows (fajr..isha) holding per-prayer user settings.
class Prayers extends Table {
  TextColumn get key => text()(); // fajr|dhuhr|asr|maghrib|isha
  BoolColumn get alarmEnabled => boolean().withDefault(const Constant(true))();
  IntColumn get offsetMinutes => integer().withDefault(const Constant(0))();
  TextColumn get soundUri => text().nullable()();
  BoolColumn get useAzan => boolean().withDefault(const Constant(false))();
  IntColumn get snoozeMinutes => integer().withDefault(const Constant(5))();
  @override
  Set<Column> get primaryKey => {key};
}

class PrayerLogs extends Table {
  TextColumn get prayerKey => text().references(Prayers, #key)();
  DateTimeColumn get date => dateTime()(); // date-only (00:00 local)
  BoolColumn get completed => boolean().withDefault(const Constant(false))();
  DateTimeColumn get markedAt => dateTime().nullable()();
  @override
  Set<Column> get primaryKey => {prayerKey, date};
}

@DataClassName('SchoolClass')
class Classes extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().withLength(min: 1, max: 100)();
  TextColumn get level => text().nullable()(); // educational level, used in AI context
  TextColumn get teacherNotes => text().nullable()();
  IntColumn get reminderMinutesBefore => integer().withDefault(const Constant(10))();
  BoolColumn get isArchived => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

class Subjects extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get classId => integer().references(Classes, #id, onDelete: KeyAction.cascade)();
  TextColumn get name => text().withLength(min: 1, max: 100)();
}

class ClassSchedules extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get classId => integer().references(Classes, #id, onDelete: KeyAction.cascade)();
  IntColumn get subjectId => integer().nullable().references(Subjects, #id)();
  IntColumn get weekday => integer()(); // 1=Mon .. 7=Sun (DateTime.weekday)
  IntColumn get startMinute => integer()(); // minutes from midnight
  IntColumn get endMinute => integer()();
  IntColumn get capacityLessons => integer().withDefault(const Constant(1))(); // lessons teachable per session
}

class Semesters extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get classId => integer().references(Classes, #id, onDelete: KeyAction.cascade)();
  TextColumn get name => text()();
  DateTimeColumn get startDate => dateTime()();
  DateTimeColumn get endDate => dateTime()();
  DateTimeColumn get examDate => dateTime().nullable()();
  TextColumn get holidaysJson => text().withDefault(const Constant('[]'))(); // ISO dates
}

// A syllabus node: chapter (parentId null) or lesson (parentId = chapter).
class SyllabusItems extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get subjectId => integer().references(Subjects, #id, onDelete: KeyAction.cascade)();
  IntColumn get semesterId => integer().nullable().references(Semesters, #id)();
  IntColumn get parentId => integer().nullable().references(SyllabusItems, #id)();
  TextColumn get title => text()();
  IntColumn get orderIndex => integer()();
  IntColumn get weight => integer().withDefault(const Constant(1))(); // relative effort
  TextColumn get homework => text().nullable()();
  // pending | completed. Set to completed ONLY by explicit user action.
  TextColumn get status => text().withDefault(const Constant('pending'))();
  DateTimeColumn get completedAt => dateTime().nullable()();
}

class DailyStudyPlans extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get syllabusItemId => integer().references(SyllabusItems, #id, onDelete: KeyAction.cascade)();
  IntColumn get semesterId => integer().references(Semesters, #id, onDelete: KeyAction.cascade)();
  DateTimeColumn get plannedDate => dateTime()();
  BoolColumn get isRecovery => boolean().withDefault(const Constant(false))();
  IntColumn get planVersion => integer().withDefault(const Constant(1))(); // 1 = original
}

class ProgressLogs extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get syllabusItemId => integer().references(SyllabusItems, #id, onDelete: KeyAction.cascade)();
  DateTimeColumn get loggedAt => dateTime().withDefault(currentDateAndTime)();
  TextColumn get action => text()(); // completed | reopened | rescheduled
  TextColumn get note => text().nullable()();
}

class AiConversations extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get classId => integer().references(Classes, #id, onDelete: KeyAction.cascade)();
  TextColumn get title => text().withDefault(const Constant('New chat'))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

class AiMessages extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get conversationId => integer().references(AiConversations, #id, onDelete: KeyAction.cascade)();
  TextColumn get role => text()(); // user | assistant
  TextColumn get content => text()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

class Reminders extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get title => text()();
  TextColumn get kind => text().withDefault(const Constant('custom'))(); // custom|exam|assignment|class|task
  DateTimeColumn get fireAt => dateTime()();
  TextColumn get repeatRule => text().nullable()(); // none|daily|weekly|monthly
  IntColumn get taskId => integer().nullable().references(Tasks, #id, onDelete: KeyAction.cascade)();
  IntColumn get classId => integer().nullable().references(Classes, #id, onDelete: KeyAction.cascade)();
  BoolColumn get fired => boolean().withDefault(const Constant(false))();
  BoolColumn get missed => boolean().withDefault(const Constant(false))();
}

class AppSettings extends Table {
  TextColumn get key => text()();
  TextColumn get value => text()();
  @override
  Set<Column> get primaryKey => {key};
}
