/// Pure Dart models for the syllabus scheduler. No Flutter/Drift imports.

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);
DateTime addDays(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);

/// A day on which teaching is possible, with how many lessons fit that day.
class TeachingDay {
  const TeachingDay(this.date, this.capacity);
  final DateTime date;
  final int capacity;
}

class PlanAssignment {
  const PlanAssignment(this.lessonId, this.date);
  final int lessonId;
  final DateTime date;
}

class PlanResult {
  const PlanResult(this.assignments, this.unscheduledLessonIds);
  final List<PlanAssignment> assignments;
  final List<int> unscheduledLessonIds;
  bool get isFeasible => unscheduledLessonIds.isEmpty;
}

enum AlternativeKind { extendDeadline, raiseDailyCapacity, deferLessons }

/// Data only; the UI turns this into a Bengali/English sentence.
class RecoveryAlternative {
  const RecoveryAlternative(this.kind, {this.count, this.date});
  final AlternativeKind kind;
  final int? count; // lessons per day, or lessons to defer
  final DateTime? date; // new deadline for extendDeadline (null = not reachable within a year)
}

class RecoveryReport {
  const RecoveryReport({
    required this.totalLessons,
    required this.completedLessons,
    required this.pendingLessons,
    required this.overdueLessons,
    required this.remainingTeachingDays,
    required this.originalPerDay,
    required this.requiredPerDay,
    required this.extraPerDay,
    required this.delayDays,
    required this.expectedCompletion,
    required this.isFeasible,
    required this.recoveryPlan,
    required this.alternatives,
  });
  final int totalLessons;
  final int completedLessons;
  final int pendingLessons;
  final int overdueLessons;
  final int remainingTeachingDays;
  final double originalPerDay;
  final double requiredPerDay; // double.infinity if no days remain
  final double extraPerDay;
  final int delayDays;
  final DateTime? expectedCompletion;
  final bool isFeasible;
  final PlanResult recoveryPlan;
  final List<RecoveryAlternative> alternatives;
  bool get isOnTrack => overdueLessons == 0;
}
