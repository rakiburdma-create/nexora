import 'models.dart';
import 'scheduler.dart';

/// Computes progress vs plan and a recovery schedule.
/// It only READS which lessons are completed; it never marks any lesson
/// complete. Completion is a user action stored elsewhere.
class RecoveryEngine {
  static RecoveryReport analyze({
    required List<int> allLessonIds, // ordered
    required Set<int> completedIds,
    required List<TeachingDay> semesterDays, // original full set of teaching days
    required DateTime today,
    required Map<int, int> weeklyCapacity,
    required DateTime lastTeachingDate,
    Set<DateTime> holidays = const {},
  }) {
    final t = dateOnly(today);
    final original = Scheduler.buildPlan(allLessonIds, semesterDays);

    final overdue = original.assignments
        .where((a) => a.date.isBefore(t) && !completedIds.contains(a.lessonId))
        .length;

    final pending =
        allLessonIds.where((id) => !completedIds.contains(id)).toList();
    final remainingDays =
        semesterDays.where((d) => !d.date.isBefore(t)).toList();

    final originalPerDay =
        semesterDays.isEmpty ? 0.0 : allLessonIds.length / semesterDays.length;
    final required = pending.isEmpty
        ? 0.0
        : remainingDays.isEmpty
            ? double.infinity
            : pending.length / remainingDays.length;
    final extra = (required.isFinite && required > originalPerDay)
        ? required - originalPerDay
        : (required.isInfinite ? double.infinity : 0.0);
    final delayDays =
        originalPerDay > 0 ? (overdue / originalPerDay).ceil() : 0;

    final plan = Scheduler.buildPlan(pending, remainingDays);
    final expected =
        plan.assignments.isEmpty ? null : plan.assignments.last.date;

    final alternatives = <RecoveryAlternative>[];
    if (!plan.isFeasible) {
      final short = plan.unscheduledLessonIds.length;
      alternatives.add(RecoveryAlternative(
        AlternativeKind.extendDeadline,
        date: _extendedDeadline(
            lastTeachingDate, weeklyCapacity, holidays, short),
      ));
      if (remainingDays.isNotEmpty) {
        alternatives.add(RecoveryAlternative(
          AlternativeKind.raiseDailyCapacity,
          count: (pending.length / remainingDays.length).ceil(),
        ));
      }
      alternatives.add(RecoveryAlternative(
        AlternativeKind.deferLessons,
        count: short,
      ));
    }

    return RecoveryReport(
      totalLessons: allLessonIds.length,
      completedLessons: completedIds.length,
      pendingLessons: pending.length,
      overdueLessons: overdue,
      remainingTeachingDays: remainingDays.length,
      originalPerDay: originalPerDay,
      requiredPerDay: required,
      extraPerDay: extra,
      delayDays: delayDays,
      expectedCompletion: expected,
      isFeasible: plan.isFeasible,
      recoveryPlan: plan,
      alternatives: alternatives,
    );
  }

  /// First date after [lastDate] by which [needed] extra lesson slots exist.
  /// Searches up to one year; returns null if not reachable.
  static DateTime? _extendedDeadline(DateTime lastDate,
      Map<int, int> weeklyCapacity, Set<DateTime> holidays, int needed) {
    final extra = Scheduler.availableTeachingDays(
      from: addDays(lastDate, 1),
      to: addDays(lastDate, 365),
      weeklyCapacity: weeklyCapacity,
      holidays: holidays,
    );
    var got = 0;
    for (final d in extra) {
      got += d.capacity;
      if (got >= needed) return d.date;
    }
    return null;
  }
}
