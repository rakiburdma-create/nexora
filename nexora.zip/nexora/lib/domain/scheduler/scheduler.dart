import 'models.dart';

class Scheduler {
  /// Last day teaching can happen: semester end, or the day before the exam
  /// if the exam falls inside the semester.
  static DateTime lastTeachingDate(DateTime semesterEnd, DateTime? examDate) {
    final end = dateOnly(semesterEnd);
    if (examDate == null) return end;
    final beforeExam = addDays(dateOnly(examDate), -1);
    return beforeExam.isBefore(end) ? beforeExam : end;
  }

  /// Days in [from, to] whose weekday (1=Mon..7=Sun) has capacity > 0
  /// in [weeklyCapacity], excluding [holidays].
  static List<TeachingDay> availableTeachingDays({
    required DateTime from,
    required DateTime to,
    required Map<int, int> weeklyCapacity,
    Set<DateTime> holidays = const {},
  }) {
    final off = holidays.map(dateOnly).toSet();
    final last = dateOnly(to);
    final days = <TeachingDay>[];
    for (var d = dateOnly(from); !d.isAfter(last); d = addDays(d, 1)) {
      final cap = weeklyCapacity[d.weekday] ?? 0;
      if (cap > 0 && !off.contains(d)) days.add(TeachingDay(d, cap));
    }
    return days;
  }

  /// Spreads [lessonIds] (already in teaching order) across [days] in
  /// proportion to each day's capacity, never exceeding a day's capacity.
  /// If lessons exceed total capacity, every day is filled and the rest are
  /// returned as unscheduled (the caller then offers alternatives).
  static PlanResult buildPlan(List<int> lessonIds, List<TeachingDay> days) {
    final n = lessonIds.length;
    if (n == 0) return const PlanResult([], []);
    final totalCap = days.fold<int>(0, (s, d) => s + d.capacity);
    if (totalCap == 0) return PlanResult(const [], List.of(lessonIds));

    final assignments = <PlanAssignment>[];
    var next = 0;
    var cum = 0;
    for (final day in days) {
      cum += day.capacity;
      // Integer round-half-up of n * cum / totalCap.
      final target = n <= totalCap
          ? (n * cum * 2 + totalCap) ~/ (2 * totalCap)
          : cum; // overflow: fill to the brim
      while (next < target && next < n) {
        assignments.add(PlanAssignment(lessonIds[next], day.date));
        next++;
      }
    }
    return PlanResult(assignments, lessonIds.sublist(next));
  }
}
