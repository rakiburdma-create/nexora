class ClassSlot {
  const ClassSlot({
    required this.id,
    required this.weekday, // 1=Mon..7=Sun
    required this.startMinute,
    required this.endMinute,
  });
  final int id;
  final int weekday;
  final int startMinute;
  final int endMinute;
}

class ConflictDetector {
  /// Slots that overlap [candidate] on the same weekday. Back-to-back slots
  /// (one ends exactly when the next starts) are NOT conflicts.
  /// Pass [ignoreId] when editing an existing slot.
  static List<ClassSlot> conflicts(
      ClassSlot candidate, Iterable<ClassSlot> existing,
      {int? ignoreId}) {
    return existing
        .where((s) =>
            s.id != ignoreId &&
            s.weekday == candidate.weekday &&
            candidate.startMinute < s.endMinute &&
            s.startMinute < candidate.endMinute)
        .toList();
  }

  static bool isValid(ClassSlot s) =>
      s.startMinute >= 0 && s.endMinute <= 1440 && s.startMinute < s.endMinute;
}
