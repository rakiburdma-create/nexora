import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppTheme {
  // System fonts are used for now (Android renders Bengali with Noto Sans Bengali).
  static TextTheme _text(TextTheme base, Color color) {
    final themed = base.apply(bodyColor: color, displayColor: color);
    return themed.copyWith(
      headlineSmall: themed.headlineSmall
          ?.copyWith(fontSize: 22, fontWeight: FontWeight.w700),
      titleMedium:
          themed.titleMedium?.copyWith(fontSize: 16, fontWeight: FontWeight.w600),
    );
  }

  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.navy,
      primary: AppColors.navy,
      secondary: AppColors.gold,
      tertiary: AppColors.emerald,
      surface: AppColors.softWhite,
      brightness: Brightness.light,
    );
    return _build(scheme, AppColors.softWhite, Colors.white, AppColors.navy);
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.gold,
      primary: AppColors.gold,
      secondary: AppColors.emerald,
      surface: AppColors.navy,
      brightness: Brightness.dark,
    );
    return _build(scheme, AppColors.navy, AppColors.navyLight, AppColors.softWhite);
  }

  static ThemeData _build(ColorScheme s, Color bg, Color card, Color text) {
    final base = ThemeData(brightness: s.brightness, useMaterial3: true);
    return base.copyWith(
      colorScheme: s,
      scaffoldBackgroundColor: bg,
      textTheme: _text(base.textTheme, text),
      cardTheme: CardThemeData(
        color: card,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: text.withOpacity(0.06)),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: bg,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: text,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: card,
        indicatorColor: AppColors.gold.withOpacity(0.25),
        height: 68,
      ),
      pageTransitionsTheme: const PageTransitionsTheme(builders: {
        TargetPlatform.android: FadeForwardsPageTransitionsBuilder(),
      }),
    );
  }
}
