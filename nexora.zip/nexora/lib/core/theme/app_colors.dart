import 'package:flutter/material.dart';

class AppColors {
  static const navy = Color(0xFF0B1B34);
  static const navyLight = Color(0xFF14284A);
  static const gold = Color(0xFFC9A961);
  static const goldSoft = Color(0xFFF1E6C8);
  static const emerald = Color(0xFF0F9D75);
  static const softWhite = Color(0xFFF8F7F3);
  static const danger = Color(0xFFD64545);
}
