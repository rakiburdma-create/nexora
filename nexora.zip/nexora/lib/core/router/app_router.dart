import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../features/classes/classes_screen.dart';
import '../../features/dashboard/dashboard_screen.dart';
import '../../features/tasks/tasks_screen.dart';
import '../../features/shell/app_shell.dart';

final _rootKey = GlobalKey<NavigatorState>();

Widget _soon(String name) => Scaffold(
      appBar: AppBar(title: Text(name)),
      body: Center(child: Text('$name — module not built yet')),
    );

final appRouter = GoRouter(
  navigatorKey: _rootKey,
  initialLocation: '/',
  routes: [
    GoRoute(path: '/tasks', builder: (_, __) => const TasksScreen()),
    StatefulShellRoute.indexedStack(
      builder: (_, __, shell) => AppShell(shell: shell),
      branches: [
        StatefulShellBranch(routes: [
          GoRoute(path: '/', builder: (_, __) => const DashboardScreen()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/notes', builder: (_, __) => _soon('Notes')),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/prayer', builder: (_, __) => _soon('Prayer')),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/classes', builder: (_, __) => const ClassesScreen()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/more', builder: (_, __) => _soon('More')),
        ]),
      ],
    ),
  ],
);
