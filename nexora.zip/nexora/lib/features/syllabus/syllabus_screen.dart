import 'package:drift/drift.dart' hide Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/db/app_database.dart';
import '../../data/providers.dart';
import '../../domain/scheduler/models.dart';
import '../../domain/scheduler/recovery.dart';
import '../../domain/scheduler/scheduler.dart';

String fmtDate(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class SyllabusScreen extends ConsumerWidget {
  const SyllabusScreen({super.key, required this.classId});
  final int classId;

  Future<Map<int, int>> _weeklyCapacity(AppDatabase db) async {
    final scheds = (await db.select(db.classSchedules).get())
        .where((s) => s.classId == classId);
    final weekly = <int, int>{};
    for (final s in scheds) {
      weekly[s.weekday] = (weekly[s.weekday] ?? 0) + s.capacityLessons;
    }
    return weekly;
  }

  Future<void> _generate(BuildContext context, WidgetRef ref, Semester sem,
      List<LessonRow> lessons) async {
    final db = ref.read(databaseProvider);
    final msg = ScaffoldMessenger.of(context);
    if (lessons.isEmpty) {
      msg.showSnackBar(const SnackBar(content: Text('Add lessons first')));
      return;
    }
    final weekly = await _weeklyCapacity(db);
    if (weekly.isEmpty) {
      msg.showSnackBar(const SnackBar(
          content: Text('This class has no days/times. Add them first.')));
      return;
    }
    final last = Scheduler.lastTeachingDate(sem.endDate, sem.examDate);
    final days = Scheduler.availableTeachingDays(
        from: sem.startDate, to: last, weeklyCapacity: weekly);
    final plan =
        Scheduler.buildPlan(lessons.map((l) => l.item.id).toList(), days);
    await db.transaction(() async {
      await (db.delete(db.dailyStudyPlans)
            ..where((p) => p.semesterId.equals(sem.id)))
          .go();
      for (final a in plan.assignments) {
        await db.into(db.dailyStudyPlans).insert(
            DailyStudyPlansCompanion.insert(
                syllabusItemId: a.lessonId,
                semesterId: sem.id,
                plannedDate: a.date));
      }
    });
    msg.showSnackBar(SnackBar(
      content: Text(plan.isFeasible
          ? 'Plan created: ${plan.assignments.length} lessons over ${days.length} teaching days'
          : '${plan.unscheduledLessonIds.length} lessons do not fit before ${fmtDate(last)}. Open Recovery for options.'),
    ));
  }

  Future<void> _recovery(BuildContext context, WidgetRef ref, Semester sem,
      List<LessonRow> lessons) async {
    final db = ref.read(databaseProvider);
    final msg = ScaffoldMessenger.of(context);
    final weekly = await _weeklyCapacity(db);
    if (lessons.isEmpty || weekly.isEmpty) {
      msg.showSnackBar(const SnackBar(
          content: Text('Need lessons and class days before analysis')));
      return;
    }
    final last = Scheduler.lastTeachingDate(sem.endDate, sem.examDate);
    final days = Scheduler.availableTeachingDays(
        from: sem.startDate, to: last, weeklyCapacity: weekly);
    final report = RecoveryEngine.analyze(
      allLessonIds: lessons.map((l) => l.item.id).toList(),
      completedIds: lessons
          .where((l) => l.item.status == 'completed')
          .map((l) => l.item.id)
          .toSet(),
      semesterDays: days,
      today: DateTime.now(),
      weeklyCapacity: weekly,
      lastTeachingDate: last,
    );
    if (!context.mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (sheetCtx) => _RecoverySheet(
        report: report,
        deadline: last,
        onApply: () async {
          Navigator.pop(sheetCtx);
          await db.transaction(() async {
            for (final a in report.recoveryPlan.assignments) {
              await (db.delete(db.dailyStudyPlans)
                    ..where((p) =>
                        p.semesterId.equals(sem.id) &
                        p.syllabusItemId.equals(a.lessonId)))
                  .go();
              await db.into(db.dailyStudyPlans).insert(
                  DailyStudyPlansCompanion.insert(
                      syllabusItemId: a.lessonId,
                      semesterId: sem.id,
                      plannedDate: a.date,
                      isRecovery: const Value(true),
                      planVersion: const Value(2)));
            }
          });
          msg.showSnackBar(
              const SnackBar(content: Text('Recovery schedule applied')));
        },
      ),
    );
  }

  /// Only called from a user tapping the checkbox. Never automatic.
  Future<void> _toggle(AppDatabase db, LessonRow l, bool done) async {
    await (db.update(db.syllabusItems)..where((x) => x.id.equals(l.item.id)))
        .write(SyllabusItemsCompanion(
      status: Value(done ? 'completed' : 'pending'),
      completedAt: Value(done ? DateTime.now() : null),
    ));
    await db.into(db.progressLogs).insert(ProgressLogsCompanion.insert(
        syllabusItemId: l.item.id, action: done ? 'completed' : 'reopened'));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);
    final cls = ref
        .watch(classesProvider)
        .value
        ?.where((c) => c.id == classId)
        .firstOrNull;
    final sems = ref.watch(semestersProvider(classId)).value ?? [];
    final sem = sems.isEmpty ? null : sems.first;
    final lessons = ref.watch(lessonsProvider(classId)).value ?? [];
    final plans = sem == null
        ? <DailyStudyPlan>[]
        : (ref.watch(plansProvider(sem.id)).value ?? []);
    final planned = {for (final p in plans) p.syllabusItemId: p.plannedDate};
    final today = dateOnly(DateTime.now());

    final total = lessons.length;
    final done = lessons.where((l) => l.item.status == 'completed').length;
    final plannedByToday = lessons
        .where((l) =>
            planned[l.item.id] != null && !planned[l.item.id]!.isAfter(today))
        .length;
    bool isOverdue(LessonRow l) =>
        l.item.status != 'completed' &&
        planned[l.item.id] != null &&
        planned[l.item.id]!.isBefore(today);
    final overdue = lessons.where(isOverdue).length;

    return Scaffold(
      appBar: AppBar(title: Text('Syllabus - ${cls?.name ?? ''}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: sem == null
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('No semester yet.'),
                        const SizedBox(height: 8),
                        FilledButton(
                          onPressed: () => showModalBottomSheet(
                            context: context,
                            isScrollControlled: true,
                            builder: (_) => _SemesterForm(classId: classId),
                          ),
                          child: const Text('Create semester'),
                        ),
                      ],
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(sem.name,
                            style: Theme.of(context).textTheme.titleMedium),
                        Text('${fmtDate(sem.startDate)}  to  ${fmtDate(sem.endDate)}'),
                        if (sem.examDate != null)
                          Text('Exam: ${fmtDate(sem.examDate!)}'),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 12),
          if (sem != null) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Progress', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(value: total == 0 ? 0 : done / total),
                    const SizedBox(height: 8),
                    Text('Completed $done / $total   Pending ${total - done}'),
                    Text('Planned by today: $plannedByToday   Overdue: $overdue',
                        style: TextStyle(
                            color: overdue > 0
                                ? Theme.of(context).colorScheme.error
                                : null)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.tonalIcon(
                onPressed: () => showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => _LessonsForm(classId: classId),
                ),
                icon: const Icon(Icons.playlist_add),
                label: const Text('Add lessons'),
              ),
              FilledButton.tonalIcon(
                onPressed: () => _generate(context, ref, sem, lessons),
                icon: const Icon(Icons.auto_fix_high),
                label: const Text('Generate plan'),
              ),
              FilledButton.icon(
                onPressed: () => _recovery(context, ref, sem, lessons),
                icon: const Icon(Icons.healing),
                label: const Text('Recovery'),
              ),
            ]),
            const SizedBox(height: 16),
            if (lessons.isEmpty)
              const Text('No lessons yet. Tap "Add lessons".'),
            for (var i = 0; i < lessons.length; i++) ...[
              if (i == 0 || lessons[i].subject.id != lessons[i - 1].subject.id)
                Padding(
                  padding: const EdgeInsets.only(top: 12, bottom: 4),
                  child: Text(lessons[i].subject.name,
                      style: Theme.of(context).textTheme.titleMedium),
                ),
              Dismissible(
                key: ValueKey('lesson-${lessons[i].item.id}'),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  color: Colors.red.withOpacity(0.8),
                  child: const Icon(Icons.delete, color: Colors.white),
                ),
                onDismissed: (_) => (db.delete(db.syllabusItems)
                      ..where((x) => x.id.equals(lessons[i].item.id)))
                    .go(),
                child: Card(
                  child: CheckboxListTile(
                    value: lessons[i].item.status == 'completed',
                    onChanged: (v) => _toggle(db, lessons[i], v ?? false),
                    title: Text(lessons[i].item.title),
                    subtitle: planned[lessons[i].item.id] == null
                        ? null
                        : Text(
                            'Planned: ${fmtDate(planned[lessons[i].item.id]!)}'
                            '${isOverdue(lessons[i]) ? '  (overdue)' : ''}',
                            style: TextStyle(
                                color: isOverdue(lessons[i])
                                    ? Theme.of(context).colorScheme.error
                                    : null),
                          ),
                  ),
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }
}

class _RecoverySheet extends StatelessWidget {
  const _RecoverySheet(
      {required this.report, required this.deadline, required this.onApply});
  final RecoveryReport report;
  final DateTime deadline;
  final Future<void> Function() onApply;

  String _rate(double v) => v.isInfinite ? 'no days left' : v.toStringAsFixed(2);

  String _alt(RecoveryAlternative a) {
    switch (a.kind) {
      case AlternativeKind.extendDeadline:
        return a.date == null
            ? 'Extending the deadline does not help within a year.'
            : 'Extend the deadline to ${fmtDate(a.date!)}.';
      case AlternativeKind.raiseDailyCapacity:
        return 'Teach ${a.count} lessons per class session.';
      case AlternativeKind.deferLessons:
        return 'Defer or merge ${a.count} lessons.';
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = report;
    final t = Theme.of(context).textTheme;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Recovery analysis', style: t.titleLarge),
            const SizedBox(height: 12),
            Text(r.isOnTrack ? 'You are on track.' : 'You are behind schedule.',
                style: t.titleMedium),
            const SizedBox(height: 8),
            Text('Completed: ${r.completedLessons} / ${r.totalLessons}'),
            Text('Remaining lessons: ${r.pendingLessons}'),
            Text('Overdue lessons: ${r.overdueLessons}'),
            Text('Delay: ${r.delayDays} day(s)'),
            Text('Remaining teaching days: ${r.remainingTeachingDays} (until ${fmtDate(deadline)})'),
            Text('Original target: ${_rate(r.originalPerDay)} lessons/day'),
            Text('Required now: ${_rate(r.requiredPerDay)} lessons/day'),
            Text('Extra workload: ${_rate(r.extraPerDay)} lessons/day'),
            if (r.expectedCompletion != null)
              Text('Expected completion: ${fmtDate(r.expectedCompletion!)}'),
            const SizedBox(height: 12),
            if (r.isFeasible)
              const Text('Recommendation: the remaining lessons fit before the deadline. '
                  'The recovery schedule spreads them across the remaining days without exceeding class capacity.')
            else ...[
              Text('The deadline cannot be met as planned. '
                  '${r.recoveryPlan.unscheduledLessonIds.length} lessons do not fit. Options:'),
              const SizedBox(height: 4),
              for (final a in r.alternatives) Text('• ${_alt(a)}'),
            ],
            const SizedBox(height: 8),
            const Text('Lessons are never marked complete automatically. '
                'Only you can confirm them.',
                style: TextStyle(fontStyle: FontStyle.italic)),
            const SizedBox(height: 12),
            if (r.recoveryPlan.assignments.isNotEmpty)
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                    onPressed: onApply,
                    child: const Text('Apply recovery schedule')),
              ),
          ],
        ),
      ),
    );
  }
}

class _SemesterForm extends ConsumerStatefulWidget {
  const _SemesterForm({required this.classId});
  final int classId;
  @override
  ConsumerState<_SemesterForm> createState() => _SemesterFormState();
}

class _SemesterFormState extends ConsumerState<_SemesterForm> {
  final _name = TextEditingController();
  DateTime? _start, _end, _exam;
  String? _error;

  Future<DateTime?> _pick(DateTime? initial) => showDatePicker(
        context: context,
        initialDate: initial ?? DateTime.now(),
        firstDate: DateTime(2020),
        lastDate: DateTime(2100),
      );

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      setState(() => _error = 'Semester name is required');
      return;
    }
    if (_start == null || _end == null) {
      setState(() => _error = 'Choose start and end dates');
      return;
    }
    if (!_end!.isAfter(_start!)) {
      setState(() => _error = 'End date must be after start date');
      return;
    }
    final db = ref.read(databaseProvider);
    await db.into(db.semesters).insert(SemestersCompanion.insert(
        classId: widget.classId,
        name: _name.text.trim(),
        startDate: dateOnly(_start!),
        endDate: dateOnly(_end!),
        examDate: Value(_exam == null ? null : dateOnly(_exam!))));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    String label(String p, DateTime? d) => d == null ? p : '$p ${fmtDate(d)}';
    return Padding(
      padding: EdgeInsets.only(
          left: 16, right: 16, top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('New semester', style: Theme.of(context).textTheme.titleLarge),
            TextField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Semester name')),
            const SizedBox(height: 8),
            OutlinedButton(
                onPressed: () async {
                  final d = await _pick(_start);
                  if (d != null) setState(() => _start = d);
                },
                child: Text(label('Start date', _start))),
            OutlinedButton(
                onPressed: () async {
                  final d = await _pick(_end);
                  if (d != null) setState(() => _end = d);
                },
                child: Text(label('End date', _end))),
            OutlinedButton(
                onPressed: () async {
                  final d = await _pick(_exam);
                  if (d != null) setState(() => _exam = d);
                },
                child: Text(label('Exam date (optional)', _exam))),
            if (_error != null)
              Text(_error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error)),
            const SizedBox(height: 8),
            SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: _save, child: const Text('Save'))),
          ],
        ),
      ),
    );
  }
}

class _LessonsForm extends ConsumerStatefulWidget {
  const _LessonsForm({required this.classId});
  final int classId;
  @override
  ConsumerState<_LessonsForm> createState() => _LessonsFormState();
}

class _LessonsFormState extends ConsumerState<_LessonsForm> {
  final _newSubject = TextEditingController();
  final _lines = TextEditingController();
  int? _sid;
  String? _error;

  Future<void> _save() async {
    final db = ref.read(databaseProvider);
    var sid = _sid;
    final newName = _newSubject.text.trim();
    final lines = _lines.text
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    if (newName.isEmpty && sid == null) {
      setState(() => _error = 'Choose a subject or type a new one');
      return;
    }
    if (lines.isEmpty) {
      setState(() => _error = 'Enter at least one lesson (one per line)');
      return;
    }
    if (newName.isNotEmpty) {
      sid = await db.into(db.subjects).insert(
          SubjectsCompanion.insert(classId: widget.classId, name: newName));
    }
    final subjectId = sid!;
    final existing = await (db.select(db.syllabusItems)
          ..where((x) => x.subjectId.equals(subjectId)))
        .get();
    var idx =
        existing.fold<int>(-1, (m, e) => e.orderIndex > m ? e.orderIndex : m) + 1;
    await db.transaction(() async {
      for (final l in lines) {
        await db.into(db.syllabusItems).insert(SyllabusItemsCompanion.insert(
            subjectId: subjectId, title: l, orderIndex: idx++));
      }
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final subjects = (ref.watch(subjectsProvider).value ?? [])
        .where((s) => s.classId == widget.classId)
        .toList();
    return Padding(
      padding: EdgeInsets.only(
          left: 16, right: 16, top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Add lessons', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            if (subjects.isNotEmpty)
              Wrap(spacing: 6, children: [
                for (final s in subjects)
                  ChoiceChip(
                    label: Text(s.name),
                    selected: _sid == s.id,
                    onSelected: (_) => setState(() => _sid = s.id),
                  ),
              ]),
            TextField(
                controller: _newSubject,
                decoration: const InputDecoration(
                    labelText: 'Or new subject name (optional)')),
            const SizedBox(height: 8),
            TextField(
              controller: _lines,
              minLines: 4,
              maxLines: 10,
              decoration: const InputDecoration(
                  labelText: 'Lessons, one per line',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder()),
            ),
            if (_error != null)
              Text(_error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error)),
            const SizedBox(height: 8),
            SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: _save, child: const Text('Save'))),
          ],
        ),
      ),
    );
  }
}
