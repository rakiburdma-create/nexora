import 'package:drift/drift.dart' hide Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/db/app_database.dart';
import '../../data/providers.dart';

class TasksScreen extends ConsumerWidget {
  const TasksScreen({super.key});

  Future<void> _add(BuildContext context, WidgetRef ref) async {
    final db = ref.read(databaseProvider);
    final c = TextEditingController();
    final key = GlobalKey<FormState>();
    final title = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New task'),
        content: Form(
          key: key,
          child: TextFormField(
            controller: c,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'Title'),
            validator: (v) =>
                (v == null || v.trim().isEmpty) ? 'Title is required' : null,
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (key.currentState!.validate()) Navigator.pop(ctx, c.text.trim());
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
    if (title != null) {
      await db.into(db.tasks).insert(TasksCompanion.insert(title: title));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);
    final tasks = ref.watch(tasksProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Tasks')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _add(context, ref),
        child: const Icon(Icons.add),
      ),
      body: tasks.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (list) {
          if (list.isEmpty) {
            return const Center(child: Text('No tasks yet. Tap + to add one.'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final t = list[i];
              return Dismissible(
                key: ValueKey(t.id),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  color: Colors.red.withOpacity(0.8),
                  child: const Icon(Icons.delete, color: Colors.white),
                ),
                onDismissed: (_) => (db.delete(db.tasks)
                      ..where((x) => x.id.equals(t.id)))
                    .go(),
                child: Card(
                  child: CheckboxListTile(
                    value: t.isDone,
                    onChanged: (v) => (db.update(db.tasks)
                          ..where((x) => x.id.equals(t.id)))
                        .write(TasksCompanion(
                      isDone: Value(v ?? false),
                      completedAt: Value((v ?? false) ? DateTime.now() : null),
                    )),
                    title: Text(t.title,
                        style: TextStyle(
                            decoration:
                                t.isDone ? TextDecoration.lineThrough : null)),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
