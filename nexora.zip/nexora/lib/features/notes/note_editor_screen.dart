import 'dart:async';
import 'package:drift/drift.dart' hide Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/db/app_database.dart';
import '../../data/providers.dart';

/// noteId == 0 means a new note. Plain-text for now; rich text comes later.
/// Auto-saves 600 ms after the last edit and again when the screen closes.
class NoteEditorScreen extends ConsumerStatefulWidget {
  const NoteEditorScreen({super.key, required this.noteId});
  final int noteId;
  @override
  ConsumerState<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends ConsumerState<NoteEditorScreen> {
  late final AppDatabase _db;
  final _title = TextEditingController();
  final _body = TextEditingController();
  Timer? _timer;
  int? _id;
  bool _fav = false, _arch = false, _trashed = false, _loaded = false;

  @override
  void initState() {
    super.initState();
    _db = ref.read(databaseProvider);
    _id = widget.noteId == 0 ? null : widget.noteId;
    _load();
  }

  Future<void> _load() async {
    final id = _id;
    if (id != null) {
      final n = await (_db.select(_db.notes)..where((x) => x.id.equals(id)))
          .getSingleOrNull();
      if (n != null) {
        _title.text = n.title;
        _body.text = n.plainText;
        _fav = n.isFavorite;
        _arch = n.isArchived;
        _trashed = n.deletedAt != null;
      }
    }
    if (mounted) setState(() => _loaded = true);
  }

  void _schedule() {
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 600), _flush);
  }

  Future<void> _flush() async {
    final title = _title.text.trim();
    final body = _body.text;
    final id = _id;
    if (id == null) {
      if (title.isEmpty && body.trim().isEmpty) return;
      _id = await _db.into(_db.notes).insert(
          NotesCompanion(title: Value(title), plainText: Value(body)));
    } else {
      await (_db.update(_db.notes)..where((n) => n.id.equals(id))).write(
          NotesCompanion(
              title: Value(title),
              plainText: Value(body),
              updatedAt: Value(DateTime.now())));
    }
  }

  Future<void> _setFlags(NotesCompanion c) async {
    await _flush();
    final id = _id;
    if (id == null) return;
    await (_db.update(_db.notes)..where((n) => n.id.equals(id))).write(c);
  }

  Future<void> _toTask() async {
    await _flush();
    var t = _title.text.trim();
    if (t.isEmpty) {
      t = _body.text.trim().split('\n').first.trim();
    }
    final messenger = ScaffoldMessenger.of(context);
    if (t.isEmpty) {
      messenger.showSnackBar(
          const SnackBar(content: Text('Write something first')));
      return;
    }
    await _db.into(_db.tasks).insert(
        TasksCompanion.insert(title: t, sourceNoteId: Value(_id)));
    messenger.showSnackBar(const SnackBar(content: Text('Task created')));
  }

  @override
  void dispose() {
    _timer?.cancel();
    if (_loaded) _flush();
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            tooltip: 'Favorite',
            icon: Icon(_fav ? Icons.star : Icons.star_border),
            onPressed: () async {
              setState(() => _fav = !_fav);
              await _setFlags(NotesCompanion(isFavorite: Value(_fav)));
            },
          ),
          IconButton(
            tooltip: 'Convert to task',
            icon: const Icon(Icons.add_task),
            onPressed: _toTask,
          ),
          IconButton(
            tooltip: _arch ? 'Unarchive' : 'Archive',
            icon: Icon(_arch ? Icons.unarchive : Icons.archive_outlined),
            onPressed: () async {
              setState(() => _arch = !_arch);
              await _setFlags(NotesCompanion(isArchived: Value(_arch)));
            },
          ),
          IconButton(
            tooltip: _trashed ? 'Restore' : 'Move to trash',
            icon: Icon(_trashed ? Icons.restore_from_trash : Icons.delete_outline),
            onPressed: () async {
              final nav = Navigator.of(context);
              await _setFlags(NotesCompanion(
                  deletedAt: Value(_trashed ? null : DateTime.now())));
              nav.pop();
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            TextField(
              controller: _title,
              onChanged: (_) => _schedule(),
              style: Theme.of(context).textTheme.headlineSmall,
              decoration: const InputDecoration(
                  hintText: 'Title', border: InputBorder.none),
            ),
            Expanded(
              child: TextField(
                controller: _body,
                onChanged: (_) => _schedule(),
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                decoration: const InputDecoration(
                    hintText: 'Write something...', border: InputBorder.none),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
