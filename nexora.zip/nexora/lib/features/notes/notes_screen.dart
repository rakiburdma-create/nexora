import 'package:drift/drift.dart' hide Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/db/app_database.dart';
import '../../data/providers.dart';

enum NoteFilter { all, favorites, archive, trash }

class NotesScreen extends ConsumerStatefulWidget {
  const NotesScreen({super.key});
  @override
  ConsumerState<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends ConsumerState<NotesScreen> {
  NoteFilter _filter = NoteFilter.all;
  String _q = '';

  bool _match(Note n) {
    final trashed = n.deletedAt != null;
    if (_filter == NoteFilter.all) {
      if (trashed || n.isArchived) return false;
    } else if (_filter == NoteFilter.favorites) {
      if (trashed || !n.isFavorite) return false;
    } else if (_filter == NoteFilter.archive) {
      if (trashed || !n.isArchived) return false;
    } else {
      if (!trashed) return false;
    }
    if (_q.isEmpty) return true;
    return n.title.toLowerCase().contains(_q) ||
        n.plainText.toLowerCase().contains(_q);
  }

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);
    final notes = ref.watch(notesProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Notes')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.push('/note/0'),
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _q = v.trim().toLowerCase()),
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'Search notes',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                for (final f in NoteFilter.values)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      label: Text(f.name[0].toUpperCase() + f.name.substring(1)),
                      selected: _filter == f,
                      onSelected: (_) => setState(() => _filter = f),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: notes.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Error: $e')),
              data: (all) {
                final list = all.where(_match).toList();
                if (list.isEmpty) {
                  return const Center(child: Text('No notes here.'));
                }
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (ctx, i) {
                    final n = list[i];
                    return Card(
                      child: ListTile(
                        title: Text(n.title.isEmpty ? 'Untitled' : n.title),
                        subtitle: Text(n.plainText,
                            maxLines: 2, overflow: TextOverflow.ellipsis),
                        trailing: _filter == NoteFilter.trash
                            ? IconButton(
                                icon: const Icon(Icons.delete_forever),
                                onPressed: () => (db.delete(db.notes)
                                      ..where((x) => x.id.equals(n.id)))
                                    .go(),
                              )
                            : (n.isFavorite
                                ? const Icon(Icons.star, color: Colors.amber)
                                : null),
                        onTap: () => ctx.push('/note/${n.id}'),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
