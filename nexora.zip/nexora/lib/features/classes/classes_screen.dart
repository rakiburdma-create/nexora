import 'package:drift/drift.dart' hide Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/db/app_database.dart';
import '../../data/providers.dart';
import '../../domain/classes/conflict_detector.dart';

const weekdayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

String fmtMinute(BuildContext c, int m) =>
    TimeOfDay(hour: m ~/ 60, minute: m % 60).format(c);

class ClassesScreen extends ConsumerWidget {
  const ClassesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);
    final classes = ref.watch(classesProvider);
    final subjects = ref.watch(subjectsProvider).value ?? [];
    final schedules = ref.watch(schedulesProvider).value ?? [];
    return Scaffold(
      appBar: AppBar(title: const Text('Classes')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (_) => const AddClassSheet(),
        ),
        icon: const Icon(Icons.add),
        label: const Text('Add class'),
      ),
      body: classes.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (list) {
          if (list.isEmpty) {
            return const Center(child: Text('No classes yet. Tap "Add class".'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (ctx, i) {
              final c = list[i];
              final subs = subjects.where((s) => s.classId == c.id).toList();
              final sch = schedules.where((s) => s.classId == c.id).toList();
              return Card(
                child: Column(children: [
                ListTile(
                  title: Text(c.name),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (subs.isNotEmpty)
                        Text('Subjects: ${subs.map((s) => s.name).join(', ')}'),
                      for (final s in sch)
                        Text('${weekdayNames[s.weekday - 1]} '
                            '${fmtMinute(ctx, s.startMinute)} - ${fmtMinute(ctx, s.endMinute)}'),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      final ok = await showDialog<bool>(
                        context: ctx,
                        builder: (d) => AlertDialog(
                          title: Text('Delete "${c.name}"?'),
                          content: const Text(
                              'Its subjects and schedule will also be deleted.'),
                          actions: [
                            TextButton(
                                onPressed: () => Navigator.pop(d, false),
                                child: const Text('Cancel')),
                            FilledButton(
                                onPressed: () => Navigator.pop(d, true),
                                child: const Text('Delete')),
                          ],
                        ),
                      );
                      if (ok == true) {
                        await (db.delete(db.classes)
                              ..where((x) => x.id.equals(c.id)))
                            .go();
                      }
                    },
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8, bottom: 4),
                    child: TextButton.icon(
                      onPressed: () => ctx.push('/syllabus/${c.id}'),
                      icon: const Icon(Icons.menu_book),
                      label: const Text('Syllabus'),
                    ),
                  ),
                ),
                ]),
              );
            },
          );
        },
      ),
    );
  }
}

class AddClassSheet extends ConsumerStatefulWidget {
  const AddClassSheet({super.key});
  @override
  ConsumerState<AddClassSheet> createState() => _AddClassSheetState();
}

class _AddClassSheetState extends ConsumerState<AddClassSheet> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _subjects = TextEditingController();
  final _days = <int>{};
  TimeOfDay _start = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _end = const TimeOfDay(hour: 10, minute: 0);
  String? _error;

  int get _sm => _start.hour * 60 + _start.minute;
  int get _em => _end.hour * 60 + _end.minute;

  Future<void> _pick(bool isStart) async {
    final t = await showTimePicker(
        context: context, initialTime: isStart ? _start : _end);
    if (t != null) setState(() => isStart ? _start = t : _end = t);
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    if (_days.isEmpty) {
      setState(() => _error = 'Select at least one day');
      return;
    }
    if (_em <= _sm) {
      setState(() => _error = 'End time must be after start time');
      return;
    }
    final db = ref.read(databaseProvider);
    final existing = (await db.select(db.classSchedules).get())
        .map((s) => ClassSlot(
            id: s.id,
            weekday: s.weekday,
            startMinute: s.startMinute,
            endMinute: s.endMinute))
        .toList();
    for (final wd in _days) {
      final clash = ConflictDetector.conflicts(
          ClassSlot(id: -1, weekday: wd, startMinute: _sm, endMinute: _em),
          existing);
      if (clash.isNotEmpty) {
        setState(() => _error =
            'Time conflict on ${weekdayNames[wd - 1]} with another class');
        return;
      }
    }
    await db.transaction(() async {
      final classId = await db
          .into(db.classes)
          .insert(ClassesCompanion.insert(name: _name.text.trim()));
      for (final s in _subjects.text
          .split(',')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)) {
        await db
            .into(db.subjects)
            .insert(SubjectsCompanion.insert(classId: classId, name: s));
      }
      for (final wd in _days) {
        await db.into(db.classSchedules).insert(ClassSchedulesCompanion.insert(
            classId: classId, weekday: wd, startMinute: _sm, endMinute: _em));
      }
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: SingleChildScrollView(
        child: Form(
          key: _form,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('New class', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Class name'),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Class name is required'
                    : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _subjects,
                decoration: const InputDecoration(
                    labelText: 'Subjects (comma separated)'),
              ),
              const SizedBox(height: 12),
              Wrap(spacing: 6, children: [
                for (var d = 1; d <= 7; d++)
                  FilterChip(
                    label: Text(weekdayNames[d - 1]),
                    selected: _days.contains(d),
                    onSelected: (v) =>
                        setState(() => v ? _days.add(d) : _days.remove(d)),
                  ),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                    child: OutlinedButton(
                        onPressed: () => _pick(true),
                        child: Text('Start ${_start.format(context)}'))),
                const SizedBox(width: 8),
                Expanded(
                    child: OutlinedButton(
                        onPressed: () => _pick(false),
                        child: Text('End ${_end.format(context)}'))),
              ]),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(_error!,
                      style: TextStyle(color: Theme.of(context).colorScheme.error)),
                ),
              const SizedBox(height: 12),
              SizedBox(
                  width: double.infinity,
                  child: FilledButton(onPressed: _save, child: const Text('Save'))),
            ],
          ),
        ),
      ),
    );
  }
}
