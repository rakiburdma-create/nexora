import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/section_card.dart';

/// Phase 1: layout + design only. Values are placeholders until providers
/// (prayer, tasks, classes, AI) are wired in their modules.
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return SafeArea(
      child: LayoutBuilder(builder: (context, c) {
        final wide = c.maxWidth > 700;
        final cards = <Widget>[
          const _NextPrayerCard(),
          SectionCard(title: 'Daily tasks', icon: Icons.check_circle_outline,
              child: const Text('No tasks yet. Tasks module pending.')),
          SectionCard(title: 'Madrasa schedule', icon: Icons.school_outlined,
              child: const Text('No classes yet. Classes module pending.')),
          SectionCard(title: 'Weekly goals', icon: Icons.flag_outlined,
              child: const LinearProgressIndicator(value: 0)),
          SectionCard(title: 'AI suggestions', icon: Icons.auto_awesome,
              child: const Text('Available after AI backend is connected.')),
        ];
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Assalamu Alaikum', style: t.textTheme.headlineSmall),
            Text('Life. Learn. Teach. Grow.',
                style: t.textTheme.bodyMedium
                    ?.copyWith(color: t.colorScheme.secondary)),
            const SizedBox(height: 16),
            const _QuickActions(),
            const SizedBox(height: 16),
            if (wide)
              Wrap(spacing: 12, runSpacing: 12, children: [
                for (final w in cards)
                  SizedBox(width: (c.maxWidth - 32 - 12) / 2, child: w)
              ])
            else
              for (final w in cards) ...[w, const SizedBox(height: 12)],
          ],
        );
      }),
    );
  }
}

class _NextPrayerCard extends StatelessWidget {
  const _NextPrayerCard();
  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Next prayer',
      icon: Icons.mosque_outlined,
      gradient: const LinearGradient(
          colors: [AppColors.navy, AppColors.navyLight],
          begin: Alignment.topLeft, end: Alignment.bottomRight),
      child: const Text('Set location to calculate prayer times',
          style: TextStyle(color: AppColors.goldSoft)),
    );
  }
}

class _QuickActions extends StatelessWidget {
  const _QuickActions();
  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.add_task, 'Task'),
      (Icons.edit_note, 'Note'),
      (Icons.alarm_add, 'Reminder'),
      (Icons.menu_book, 'Lesson'),
    ];
    return Row(
      children: [
        for (final i in items)
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(right: 8),
              child: FilledButton.tonalIcon(
                onPressed: null, // enabled when each module is built
                icon: Icon(i.$1, size: 18),
                label: Text(i.$2, overflow: TextOverflow.ellipsis),
              ),
            ),
          ),
      ],
    );
  }
}
