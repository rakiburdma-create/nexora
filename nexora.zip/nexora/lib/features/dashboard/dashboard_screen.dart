import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/section_card.dart';
import '../../data/providers.dart';
import '../classes/classes_screen.dart' show fmtMinute;

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = Theme.of(context);
    final tasks = ref.watch(tasksProvider).value ?? [];
    final pending = tasks.where((x) => !x.isDone).toList();
    final schedules = ref.watch(schedulesProvider).value ?? [];
    final classes = ref.watch(classesProvider).value ?? [];
    final today = DateTime.now().weekday;
    final todays = schedules.where((s) => s.weekday == today).toList()
      ..sort((a, b) => a.startMinute.compareTo(b.startMinute));
    String className(int id) =>
        classes.where((c) => c.id == id).map((c) => c.name).firstOrNull ?? '';

    final cards = <Widget>[
      const _NextPrayerCard(),
      SectionCard(
        title: 'Daily tasks',
        icon: Icons.check_circle_outline,
        onTap: () => context.push('/tasks'),
        child: pending.isEmpty
            ? const Text('No pending tasks. Tap to add.')
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${pending.length} pending'),
                  for (final x in pending.take(3)) Text('• ${x.title}'),
                ],
              ),
      ),
      SectionCard(
        title: "Today's classes",
        icon: Icons.school_outlined,
        onTap: () => context.go('/classes'),
        child: todays.isEmpty
            ? const Text('No classes today.')
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final s in todays)
                    Text('${fmtMinute(context, s.startMinute)} - '
                        '${fmtMinute(context, s.endMinute)}  ${className(s.classId)}'),
                ],
              ),
      ),
      const SectionCard(
          title: 'AI suggestions',
          icon: Icons.auto_awesome,
          child: Text('Available after the AI backend is connected.')),
    ];

    return SafeArea(
      child: LayoutBuilder(builder: (context, c) {
        final wide = c.maxWidth > 700;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Assalamu Alaikum', style: t.textTheme.headlineSmall),
            Text('Life. Learn. Teach. Grow.',
                style: t.textTheme.bodyMedium
                    ?.copyWith(color: t.colorScheme.secondary)),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: () => context.push('/tasks'),
                  icon: const Icon(Icons.add_task, size: 18),
                  label: const Text('Tasks'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: () => context.go('/classes'),
                  icon: const Icon(Icons.school, size: 18),
                  label: const Text('Classes'),
                ),
              ),
            ]),
            const SizedBox(height: 16),
            if (wide)
              Wrap(spacing: 12, runSpacing: 12, children: [
                for (final w in cards)
                  SizedBox(width: (c.maxWidth - 32 - 12) / 2, child: w)
              ])
            else
              for (final w in cards) ...[w, const SizedBox(height: 12)],
          ],
        );
      }),
    );
  }
}

class _NextPrayerCard extends StatelessWidget {
  const _NextPrayerCard();
  @override
  Widget build(BuildContext context) {
    return const SectionCard(
      title: 'Next prayer',
      icon: Icons.mosque_outlined,
      gradient: LinearGradient(
          colors: [AppColors.navy, AppColors.navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight),
      child: Text('Prayer module coming next',
          style: TextStyle(color: AppColors.goldSoft)),
    );
  }
}
