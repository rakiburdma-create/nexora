import 'package:flutter_test/flutter_test.dart';
import 'package:nexora/domain/scheduler/models.dart';
import 'package:nexora/domain/scheduler/recovery.dart';
import 'package:nexora/domain/scheduler/scheduler.dart';

DateTime d(int day) => DateTime(2026, 1, day);

void main() {
  const everyDay = {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1};
  final ids = List.generate(10, (i) => i + 1);
  final days = Scheduler.availableTeachingDays(
      from: d(5), to: d(14), weeklyCapacity: everyDay); // 10 days

  test('behind and impossible: reports delay, extra load, alternatives', () {
    final r = RecoveryEngine.analyze(
      allLessonIds: ids,
      completedIds: {1},
      semesterDays: days,
      today: d(8),
      weeklyCapacity: everyDay,
      lastTeachingDate: d(14),
    );
    expect(r.overdueLessons, 2);
    expect(r.delayDays, 2);
    expect(r.pendingLessons, 9);
    expect(r.remainingTeachingDays, 7);
    expect(r.requiredPerDay, closeTo(9 / 7, 1e-9));
    expect(r.extraPerDay, closeTo(9 / 7 - 1, 1e-9));
    expect(r.isFeasible, false);
    final kinds = r.alternatives.map((a) => a.kind).toList();
    expect(kinds, [
      AlternativeKind.extendDeadline,
      AlternativeKind.raiseDailyCapacity,
      AlternativeKind.deferLessons,
    ]);
    expect(r.alternatives[0].date, d(16)); // 2 extra single-lesson days
    expect(r.alternatives[1].count, 2);
    expect(r.alternatives[2].count, 2);
  });

  test('on track when nothing is overdue', () {
    final r = RecoveryEngine.analyze(
      allLessonIds: ids,
      completedIds: {1, 2, 3},
      semesterDays: days,
      today: d(8),
      weeklyCapacity: everyDay,
      lastTeachingDate: d(14),
    );
    expect(r.isOnTrack, true);
    expect(r.isFeasible, true);
    expect(r.alternatives, isEmpty);
    expect(r.expectedCompletion, d(14));
  });

  test('recovery respects capacity when sessions can hold 2 lessons', () {
    final cap2 = {for (var i = 1; i <= 7; i++) i: 2};
    final days2 = Scheduler.availableTeachingDays(
        from: d(5), to: d(14), weeklyCapacity: cap2);
    final r = RecoveryEngine.analyze(
      allLessonIds: ids,
      completedIds: {1},
      semesterDays: days2,
      today: d(8),
      weeklyCapacity: cap2,
      lastTeachingDate: d(14),
    );
    expect(r.isFeasible, true);
    for (final day in days2) {
      final n = r.recoveryPlan.assignments.where((a) => a.date == day.date).length;
      expect(n <= 2, true);
    }
  });

  test('no remaining days gives infinite requirement, not a crash', () {
    final r = RecoveryEngine.analyze(
      allLessonIds: ids,
      completedIds: {1},
      semesterDays: days,
      today: d(20),
      weeklyCapacity: everyDay,
      lastTeachingDate: d(14),
    );
    expect(r.requiredPerDay.isInfinite, true);
    expect(r.isFeasible, false);
  });

  test('does not change completion state', () {
    final done = <int>{1};
    RecoveryEngine.analyze(
      allLessonIds: ids, completedIds: done, semesterDays: days,
      today: d(8), weeklyCapacity: everyDay, lastTeachingDate: d(14),
    );
    expect(done, {1});
  });
}
