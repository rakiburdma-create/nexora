import 'package:flutter_test/flutter_test.dart';
import 'package:nexora/domain/scheduler/models.dart';
import 'package:nexora/domain/scheduler/scheduler.dart';

DateTime d(int day) => DateTime(2026, 1, day); // 5 Jan 2026 is a Monday

void main() {
  group('availableTeachingDays', () {
    test('uses weekdays with capacity', () {
      final days = Scheduler.availableTeachingDays(
          from: d(5), to: d(11), weeklyCapacity: {1: 1, 3: 1});
      expect(days.map((e) => e.date), [d(5), d(7)]);
    });
    test('skips holidays', () {
      final days = Scheduler.availableTeachingDays(
          from: d(5), to: d(11), weeklyCapacity: {1: 1, 3: 1}, holidays: {d(7)});
      expect(days.map((e) => e.date), [d(5)]);
    });
  });

  group('lastTeachingDate', () {
    test('day before exam when exam is inside semester', () {
      expect(Scheduler.lastTeachingDate(d(30), d(20)), d(19));
    });
    test('semester end when no exam', () {
      expect(Scheduler.lastTeachingDate(d(30), null), d(30));
    });
  });

  group('buildPlan', () {
    final four = [for (var i = 5; i < 9; i++) TeachingDay(d(i), 1)];

    test('one lesson per day when counts match', () {
      final r = Scheduler.buildPlan([1, 2, 3, 4], four);
      expect(r.isFeasible, true);
      expect(r.assignments.map((a) => a.date), four.map((e) => e.date));
    });
    test('spreads fewer lessons evenly, not front-loaded', () {
      final r = Scheduler.buildPlan([1, 2], four);
      expect(r.assignments.map((a) => a.date), [d(5), d(7)]);
    });
    test('reports unscheduled lessons when over capacity', () {
      final r = Scheduler.buildPlan([1, 2, 3, 4, 5], four.take(3).toList());
      expect(r.assignments.length, 3);
      expect(r.unscheduledLessonIds, [4, 5]);
      expect(r.isFeasible, false);
    });
    test('never exceeds a day capacity', () {
      final days = [
        TeachingDay(d(5), 2), TeachingDay(d(6), 1),
        TeachingDay(d(7), 3), TeachingDay(d(8), 2),
      ];
      final r = Scheduler.buildPlan([1, 2, 3, 4, 5, 6, 7], days);
      expect(r.isFeasible, true);
      for (final day in days) {
        final n = r.assignments.where((a) => a.date == day.date).length;
        expect(n <= day.capacity, true);
      }
    });
    test('keeps lesson order', () {
      final r = Scheduler.buildPlan([10, 20, 30], four);
      expect(r.assignments.map((a) => a.lessonId), [10, 20, 30]);
    });
    test('empty inputs', () {
      expect(Scheduler.buildPlan([], four).isFeasible, true);
      expect(Scheduler.buildPlan([1], []).unscheduledLessonIds, [1]);
    });
  });
}
