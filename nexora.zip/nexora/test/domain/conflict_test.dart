import 'package:flutter_test/flutter_test.dart';
import 'package:nexora/domain/classes/conflict_detector.dart';

ClassSlot s(int id, int wd, int a, int b) =>
    ClassSlot(id: id, weekday: wd, startMinute: a, endMinute: b);

void main() {
  final existing = [s(1, 1, 540, 600)]; // Mon 09:00-10:00
  test('overlap is a conflict', () {
    expect(ConflictDetector.conflicts(s(2, 1, 570, 630), existing).length, 1);
  });
  test('back-to-back is not a conflict', () {
    expect(ConflictDetector.conflicts(s(2, 1, 600, 660), existing), isEmpty);
  });
  test('different weekday is not a conflict', () {
    expect(ConflictDetector.conflicts(s(2, 2, 540, 600), existing), isEmpty);
  });
  test('editing a slot ignores itself', () {
    expect(ConflictDetector.conflicts(s(1, 1, 550, 610), existing, ignoreId: 1), isEmpty);
  });
  test('validity', () {
    expect(ConflictDetector.isValid(s(1, 1, 600, 540)), false);
    expect(ConflictDetector.isValid(s(1, 1, 540, 600)), true);
  });
}
